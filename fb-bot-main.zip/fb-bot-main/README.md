# Facebook Bot
‌Auto Commenter & Auto Sharer

# Commands

pkg uninstall python

pkg install python

cd

rm -rf fb-bot

git clone https://github.com/TechnicalZahid/fb-bot.git

cd fb-bot

python Zking-bot.py

# Facebook Bot
‌‌‌Auto tagger 

# Commands

rm -rf fb-bot

git clone https://github.com/TechnicalZahid/fb-bot.git

cd fb-bot

python tagger.py

# Facebook Bot
‌‌‌‌auto Follower

# Commands

rm -rf fb-bot

git clone https://github.com/TechnicalZahid/fb-bot.git

cd fb-bot

python Zking-liker.py
